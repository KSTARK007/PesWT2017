<?php
var_dump(exec("dir",$arr));
var_dump(exec("whoami"));
echo "<br>";
var_dump($arr);
 ?>
